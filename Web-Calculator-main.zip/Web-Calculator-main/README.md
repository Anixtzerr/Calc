<h3 align="center">A simple web-based calculator, built with Vanilla JS<br>
    <a href="https://a-partovii.github.io/Web-Calculator/src/web-calculator.html">
        👉Check Online👈
    </a>
</h3>
<br>
<p align="center"> 
    <img src="https://img.shields.io/badge/HTML5-E34F26?logo=html5&logoColor=fff">&nbsp
    <img src="https://img.shields.io/badge/CSS3-1572B6?logo=css3&logoColor=fff">&nbsp
    <img src="https://img.shields.io/badge/JavaScript-F7DF1E?logo=javascript&logoColor=000">
    <br>
    <img width="450" src="https://github.com/user-attachments/assets/72b5389b-2b5a-4f36-a888-05e382b531de"  alt="Preview Picture">
</p>
